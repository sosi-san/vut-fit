#!/usr/bin/python
import socket, re, sys, getopt, signal

found = False
badRequest = False
methodNotAllowed = False

def signal_handler(sig, frame):
    global s
    s.close()
    sys.exit(0)
def resolveRequest(requestData):
    global found, badRequest
    requestData = requestData.split(":")
    tmp = requestData[0]
    if(len(requestData) != 2):
        return ""
    try:
        if requestData[1] == "A":
            requestData.append(socket.gethostbyname(requestData[0].strip()))
        elif requestData[1] == "PTR":
             requestData.append(socket.gethostbyaddr(requestData[0].strip())[0])
        else:
            badRequest = True
            return ""
    except socket.gaierror:
        return ""
    if requestData[2] == tmp:
        badRequest = True
        return ""
    found = True
    return requestData[0]+":"+requestData[1]+"="+requestData[2]+"\n"
argv = sys.argv[1:]
try:
    opts, args = getopt.getopt(argv, 'p', ['PORT='])
except getopt.GetoptError:
    sys.exit(2)
port = None
for o, a in opts:
        if o == "--PORT":
            port = a
        else:
            sys.exit(2)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("127.0.0.1", int(port)))
s.listen(5)
data = ""
signal.signal(signal.SIGINT, signal_handler)
while True:
    clientsocket, address = s.accept()
    found = False
    badRequest = False
    methodNotAllowed = False
    with clientsocket:
        data = clientsocket.recv(4096).decode("utf-8")
        data = re.sub('( ){1,}:( ){1,}', ':', data)
        data = data.split(" ")
        if data[0] == "GET":
            data = [":".join(data[1].replace("/resolve?name=","",1).split("&type="))]
        elif data[0] == "POST":
            data = data[-1].split("application/x-www-form-urlencoded\r\n\r\n")[1].replace("\r\n\r\n","\r\n").split("\r\n")
        else:
            methodNotAllowed = True
        msg = ""
        if methodNotAllowed != True:
            for i in range(len(data)):
                msg += resolveRequest(data[i])
        if methodNotAllowed == True:
            msg = "HTTP/1.1 405 Method Not Allowed\r\n\r\n"
        elif found == True:
            msg = "HTTP/1.1 200 OK\r\n\r\n" + msg
        elif badRequest == True:
            msg = "HTTP/1.1 400 Bad Request\r\n\r\n" + msg
        else:
            msg = "HTTP/1.1 404 Not Found\r\n\r\n" + msg
        clientsocket.send(bytes(msg,"utf-8"))
        clientsocket.close()