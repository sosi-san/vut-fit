###### Informace
IPK - Počítačové komunikace a sítě
Projekt 1 - 	HTTP resolver doménových jmen
Autor - Adam Woska
######Implementace projektu
Pro vytvoření projektu jsem zvolil jazyk python. Jelikož je pomocí něho lze jednoduše implementovat server.  Při získání dotazu (ať už je dotaz typu GET či POST) si postupně dotaz naformátuji tak aby měl na konci stejný tvar pro oba typy dotazů. Ty jsou uloženy do pole a pro jednotlivé dotazy se volá funkce. Které podle vstupních dat vrátí příslušnou odpověď (ve tvaru DOTAZ:TYP=ODPOVED) . Zároveň se v ní vztyčují "flagy" podle kterých poté poznám s jakou hlavičkou mám odeslat odpověď. Pro projití všech dotazů se zkontrolují již zmíněné flagy a odešle se odpověď.